# bailing/connect —— 百灵中枢业务侧接入 SDK（PHP）

把你的业务接口安全地开放给 AI，只需三步：**标注解 → 发布 spec → 验签名**。
零依赖，PHP ≥ 8.1。能力声明遵循 ACC，验签与中枢接入约定见 `docs/CONTRACT.md §2.4`。

## 安装

未发布 packagist 前三种方式任选：

```bash
# ① 从你的中枢直接下载（控制台「工具源 → 接入说明」也有此链接）
curl -O https://<中枢域名>/connect/bailing-connect-php.tgz && tar -xzf bailing-connect-php.tgz
```

```jsonc
// ② composer.json（path 仓库，指向解压/克隆出来的目录）
{
  "repositories": [{ "type": "path", "url": "./bailing-connect-php" }],
  "require": { "bailing/connect": "*" }
}
```

或 ③ 直接拷贝 `src/` 目录进项目。零依赖，怎么引都行；请保留完整目录结构，避免可选模块 class not found。

## 第一步：标注解

在现有控制器方法上加 `#[AiTool]`（不影响原有调用方）：

```php
use Bailing\Connect\Attributes\{AiTool, AiParam};

#[AiTool(
    description: '查询门店员工列表',
    scope: 'tenant.staff.read',
    path: '/opentenantapi/staff/list',
    whenToUse: '用户问员工、排班、人事时',
    returns: '{code:1, data:[{id,name,role,dept}]}',
    examples: [['dept' => '前厅']],
)]
#[AiParam('dept', description: '按部门过滤', enum: ['前厅', '后仓'])]
public function list() { /* 你原有的逻辑 */ }
```

完整字段见 `src/Attributes/AiTool.php` 注释（每个字段都有说明），覆盖范例见
`examples/DemoStaffController.php`。要点：

- **写接口**必须 `#[AiParam]` 声明参数、按需标 `risk: 'high'` / `confirm: true`（进人工审批）；
- **按参数升级确认**用 `confirmWhen`，例如金额超过阈值、跨主体、敏感字段命中才确认；
- **POST 实现的查询**标 `readonly: true`，AI 才敢放心调；
- **必须登录才有意义的接口**标 `requiresSubject: true`——匿名网页访客直接看不到它；
- **参数含手机号等敏感数据**标 `sensitive: true`——中枢审计只记键名。

构建期即体检：scope 缺失、写接口无参数、工具名重复等会**直接抛异常**，
不会等发布后才在控制台"被跳过"列表里发现。

### 显式声明与缺省值

`readonly`、`idempotent` 的显式 `true` / `false` 和 `risk` 的显式 `low` / `medium` / `high` 都会原样写入 ACC；未设置的字段保持省略。按 ACC v1 的 OpenAPI binding，只有未显式声明只读性时才使用 GET 的缺省信号。因此 GET + `readonly: false` 且未设置 risk 的有效风险是 `medium`；POST + `risk: 'low'` 的有效风险是 `low`，既有审批与最终业务授权要求仍然保留。

升级后请重新生成、核对并刷新工具源声明。过去被省略的显式值现在会出现，JSON/ETag 可能变化，但 ACC 的 `version: 1` 不变。不需要批量给写接口添加 `risk: 'low'`。

PHP 注解模型的 `AiTool::$risk` 现在是 `?string`，默认 `null` 表示未设置；构造参数名称和顺序不变。已有显式字符串声明保持兼容；若接入代码自行读取该属性，应处理 `null`，不要把它解释为统一的 low 风险。

实际生成器回归（24 种 readonly/risk 组合、6 种幂等声明组合及审批/主体保留检查）：

```bash
php tests/declaration-serialization.php
# 用同一套测试检查另一个解包目录：
php tests/declaration-serialization.php /path/to/bailing-connect-php
```

## 第二步：发布 spec（约定路径）

```
https://你的域名/.well-known/bailing/tools.json
```

ThinkPHP 路由一段（完整示例见 `examples/thinkphp-integration.php`）：

```php
Route::get('.well-known/bailing/tools.json', function () {
    $secret = config('bailing.tool_secret');
    $spec = (new \Bailing\Connect\SpecBuilder(title: '你的业务系统'))
        ->authzProbe('/.well-known/bailing/authz-probe')
        ->addClass(StaffController::class);
    [$status, $body] = \Bailing\Connect\SpecServer::handle(
        $spec, $secret,
        request()->method(), request()->url(), request()->header());
    $response = response($body, $status);
    $response->header(\Bailing\Connect\SpecServer::responseHeaders($secret));
    return $response;
});
```

- `->authzProbe(...)` 会在 spec 根上声明 `x-bailing-authz-probe`。中枢刷新工具源时，会用一个不存在的主体探测该端点，确认业务侧授权闸是默认拒绝；
- `$secret` 传中枢「工具源」登记的密钥 = **spec 只对中枢开放**（中枢拉取自带 `sha256=` 签名）；`responseHeaders($secret)` 会同时给框架响应加 `Cache-Control: private, no-store`，裸 PHP `respond()` 则自动添加，避免代理/CDN 缓存后旁路公开；
- 确实要公开能力清单时，在控制台明确选“允许公开”，代码用 `SpecServer::handlePublic(...)` 或 `SpecServer::respondPublic(...)`。旧的 `handle(..., null, ...)` / `respond(..., null, ...)` 继续兼容，但不再推荐用一个 `null` 隐藏安全决定；公开清单不等于公开工具调用，后者仍须验签并授权；
- 中枢侧开"自动刷新"后，你**每次部署新标注的接口自动成为 AI 工具**，无需任何人工导入；工具清单增删/风险变化中枢会审计并告警管理员；
- 实时反射模式下注解写错 spec 端点会回 500（响应体带具体错误）；**用 `$cacheFile` 时改注解后必须重新生成缓存文件**，否则一直发旧 spec——建议 CI 里固定跑构建脚本落盘。

明确公开时对应代码应直接写出公开意图，而不是把密钥变量改成空值：

```php
Route::get('.well-known/bailing/tools.json', function () {
    $spec = (new \Bailing\Connect\SpecBuilder(title: '你的业务系统'))
        ->addClass(StaffController::class);
    [$status, $body] = \Bailing\Connect\SpecServer::handlePublic(
        $spec, request()->method(), request()->url(), request()->header());
    return response($body, $status)->contentType('application/json');
});
```

这段代码必须与控制台的 `public_allowed` 同时出现；如果控制台选 `signed_required`，业务端点就必须使用前面的受保护示例。

同路径再挂一个独立授权探针端点（不要复用真实业务工具）：

```php
Route::post('.well-known/bailing/authz-probe', function () {
    [$status, $body] = \Bailing\Connect\SpecServer::authzProbe(
        config('bailing.tool_secret'),
        // 这里必须走你自己的权限表；不存在的主体应返回 false。
        fn (string $subject): bool => $subject !== '' && PermissionService::canUseAiTools($subject),
        request()->method(),
        request()->url(),
        request()->getInput(),
        request()->header()
    );
    return response($body, $status)->contentType('application/json');
});
```

裸 PHP 可用便捷入口：`\Bailing\Connect\SpecServer::respondAuthzProbe($secret, fn ($subject) => PermissionService::canUseAiTools($subject), '/.well-known/bailing/authz-probe');`。

### ⚠️ 宝塔/BT 面板必读（实测翻车点）

宝塔默认 vhost 自带 `location ~ \.well-known { allow all; }` 证书验证段，**正则 location 优先于框架重写**，导致：
- 动态路由方式 → 请求被当静态文件，**404 根本到不了 PHP**；
- 静态文件方式（CI 写 `public/.well-known/bailing/tools.json`）→ 被宝塔 lua 块**对任何人公开直出，签名保护静默失效**。

两个修法任选其一：

```nginx
# 方法①：网站设置 → 配置文件，加这段（^~ 前缀匹配优先于正则，请求才能进 PHP 路由）。
# 注意 ?s=$1 必须带：ThinkPHP 在 nginx+FPM 下靠 s 参数恢复 pathinfo（REQUEST_URI 链路 cli 才生效），
# 裸 rewrite ^ /index.php 会丢路径、路由到默认页。Laravel 等直接解析 REQUEST_URI 的框架则不需要 s 参数。
location ^~ /.well-known/bailing/ {
    rewrite ^(.*)$ /index.php?s=$1 last;
}
```

方法②：**约定路径并非强制**——中枢注册工具源时 `spec_url` 是任意 URL，直接把发布路由挂在非点开头路径（如 `/bailing/tools.json`）即可，绕开宝塔点路径的所有特殊处理。

## 第三步：验签中间件

挂在暴露给 AI 的路由分组上（约 10 行，见 `examples/thinkphp-integration.php` ②）：

```php
// 最省事：currentRequest 从超全局取齐材料（裸 PHP / 多数框架可用）
if (!Verify::currentRequest($secret)) { /* 401 */ }

// 或手动传（ThinkPHP 等）：把主体+任务两个头一并传入，纳入验签材料
$ok = Verify::toolCall($secret, $request->method(), $request->url(),
    $request->getInput(), $request->header('x-bailing-timestamp', ''),
    $request->header('x-bailing-signature', ''), 300,
    $request->header('x-bailing-on-behalf-of', ''), $request->header('x-bailing-job-id', ''));
```

> **单一签名方案 `sha256=`**（算法名，非版本号；GitHub `X-Hub-Signature-256` 同款）。验签材料把 `X-Bailing-On-Behalf-Of` + `X-Bailing-Job-Id` 纳入 HMAC（协议层钉死"谁/哪个任务"，防窗口内重放篡改这两个头换租户/绕幂等，见 CONTRACT §2.4b）。用 `toolCall` 手动验签时记得把这两个头传进去（用 `currentRequest` 则自动取齐）。当前只接受 `sha256=` 标签；未来若改签名构造按 `docs/兼容性与升级.md` 走新标签 + 过渡窗。

**边界**：验签只回答"真是中枢发的吗"。`Verify::onBehalfOf()` 是谁、有没有权限做这件事，
由你用自己既有的权限体系裁决——AI 调用与人点按钮走同一条裁决路径。

联调与加固三件事：

- **先给服务器对时**（ntp/chrony）——验签失败的头号原因是时钟偏移。`Verify::failureReason()` 区分
  `timestamp_out_of_window` / `bad_signature`，401 响应里带上能省一半联调时间；
- **用原始 `REQUEST_URI` 验签，不要 decode 后重组**——中枢"签所发即所发"；URI 会被重写/重编码的
  CDN/网关后面验签必挂，中枢侧 base_url 要指源站直连地址；
- **防重放（可选加固）**：`sha256=` 签名不携带 nonce（验签零状态）。对高敏写接口，把收到的 `X-Bailing-Signature`
  缓存 300 秒拒绝重复出现即等价 nonce 去重（签名含时间戳，本身就是唯一指纹；AI 合法重试时间戳不同不受影响）：
  ```php
  if (!$redis->set('bailing:sig:' . md5($sig), 1, ['nx', 'ex' => 300])) {
      return json(['error' => 'replay rejected'], 401);
  }
  ```

## 附：聊天组件带登录身份

```php
// 单租户：裸 uid
$ticket = \Bailing\Connect\Ticket::sign($接入方token, (string) $user->id);
// 🟢 多租户推荐：把租户维度一起编进主体（中枢原样回传，零改动支持任意租户模型）
$ticket = \Bailing\Connect\Ticket::sign($接入方token, $tenantId . ':' . $user->id);  // 如 "tenant_179:user_1"
// <script src=".../widget.js" data-entry="pub_x" data-ticket="<?= $ticket ?>">
```

接入方 token 永不进前端——进前端的只有签好的短票（默认 2 小时过期）。

**多租户姿势（强烈建议从第一天就用）**：`onBehalfOf()` 返回的是你签进票据的值**原样**，中枢不解析、不约束格式（≤64 字节）。多租户系统应把**定位一个操作人所需的全部维度**编进这一个串（如 `"{$tenantId}:{$uid}"`），验签后 `explode(':', ...)` 拆出来**先按租户划数据边界、再认定操作人**。只签裸 `uid` 在单组织能跑，接第二个租户时 `uid=1` 会跨租户撞车，且中枢无处补救（租户隔离是你的业务域知识，不该进通用契约）。单租户也建议直接用 `"tenant_1:user_1"` 这类结构化主体，免日后回头改签发逻辑+清历史。详见中枢 `docs/CONTRACT.md §2.4 b)`。

## 附：业务后端主动调中枢

```php
$hub = new \Bailing\Connect\HubClient('https://hub.example.com', $接入方token);

$job = $hub->run('crm_1001', 'order-support', '查询订单处理建议', [
    'principal' => ['id' => (string) $user->id, 'tenant' => (string) $tenantId],
]);

$result = $hub->getJob($job['job_id']);
$hub->send('notice_1001', 'team-im', 'user_001', '任务已完成');
```

## 附：本地 Agent 网页授权（可选）

`AgentAuth` 是现有 SDK 的可选模块，不是第二套 SDK。业务网页先用自己的登录态确定当前操作人，后端再用接入方 Client Token 调中枢：

完整的组件关系、配置归属与非 PHP HTTP 契约分别见
[Agent Client v1 接入指南](../../docs/AGENT_CLIENT_QUICKSTART.md) 和
[Agent Auth v1](../../docs/AGENT_AUTH_API.md)。

```php
$agentAuth = new \Bailing\Connect\AgentAuth('https://hub.example.com', $clientToken);
$context = $agentAuth->context($authorizationId);

$result = $agentAuth->approve(
    $authorizationId,
    ['id' => (string) $user->id, 'tenant' => (string) $tenantId, 'roles' => $user->roles],
    "tenant_{$tenantId}:user_{$user->id}",
    $context['requested_routes']
);

// 浏览器跳转 $result['redirect_uri'] 完成 loopback 回调。
// 用户取消时：$agentAuth->deny($authorizationId);
// 员工离职/设备丢失：$agentAuth->revokeSession($sessionId);
```

`principal` 和 `on_behalf_of` 必须由业务后端从当前登录态生成，不得从前端表单原样透传。该协议只绑定业务身份、路由与设备会话，不承载套餐、付费或权益字段。

**Core 0.7.0 配套的生命周期接口**支持核对和收回现有授权。请同时升级本 SDK 下载包与 Core。业务后端可以先查询自己有权管理的租户，再按原授权记录撤销：

```php
$page = $agentAuth->listSessions(['tenant' => (string) $tenantId, 'limit' => 20]);
$session = $agentAuth->context($authorizationId)['session'] ?? null;
$revoked = $agentAuth->revokeAuthorization($authorizationId);
```

`listSessions()` 默认 20 条，最大 100；下一页原样保留筛选条件并传 `next_cursor`，返回 null 即结束。
按操作人筛选必须同时传 `principal_id` 与 `tenant`，无租户用 `tenant => ''`。分页反映当前状态，
不是跨请求快照。`session` 缺失/null 不可猜测；`active` 不保证业务账号仍有权限，过期按 refresh
生命周期判断。撤销可按同一授权 ID 幂等重试，503/超时或 consumed 映射缺失的 404 不代表成功。
Client Token 与管理权限判断均留在业务后端；字段规则见上方 Agent Auth 契约。

### 授权后显示业务名称

Core 0.7.0 支持批准授权时附上服务端读取的业务名称。原四参数调用保持兼容；第五参数可选，名称可用于门店、公司、项目等业务对象。

```php
$result = $agentAuth->approve($authorizationId, $principal, $onBehalfOf, $allowedRoutes, array('name' => $accountName));
$session = $agentAuth->updateSubjectDisplay($sessionId, array('name' => $accountName));
// 仅清除显示信息，不撤销或替换授权：
$session = $agentAuth->updateSubjectDisplay($sessionId, null);
```

名称由业务后端从真实记录读取，不参与身份或权限判断；更新只允许当前接入方自己的有效会话。
旧授权没有名称时显示待同步，不需要重新登录或重建连接。详见
[授权名称与三方职责](../../docs/AGENT_SUBJECT_DISPLAY.md)。

## CI 集成

```bash
php examples/build-spec.php > public/.well-known/bailing/tools.json  # 构建失败=标注有错，挡住部署
```

—— 百灵中枢
